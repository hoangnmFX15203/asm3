const path = {
    PUBLIC: '/',
    HOME: '',
    ALL: '*',
    LOGIN: 'login',
    PRODUCTS: 'products',
    OUR_SERVICES: 'services',
    FAQs: 'faq',
    DETAIL_PRODUCT__PID__TITLE: 'san-pham/:pid/:title',
    DETAIL_PRODUCT: 'san-pham',
};

export default path;
