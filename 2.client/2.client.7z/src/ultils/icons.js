import {
    BsFillTelephoneFill,
    BsBagPlusFill,
    BsFillHeartFill,
} from 'react-icons/bs';
import { MdEmail } from 'react-icons/md';
import { FaUser } from 'react-icons/fa';
import {
    AiFillHome,
    AiFillStar,
    AiOutlineStar,
    AiFillEye,
    AiOutlineMenu,
} from 'react-icons/ai';

const icons = {
    BsFillTelephoneFill,
    MdEmail,
    BsBagPlusFill,
    FaUser,
    AiFillHome,
    AiFillStar,
    AiOutlineStar,
    AiFillEye,
    AiOutlineMenu,
    BsFillHeartFill,
};

export default icons;
