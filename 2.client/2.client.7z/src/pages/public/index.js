export { default as Home } from './home';
export { default as Login } from './login';
export { default as Public } from './public';
export { default as Products } from './products';
export { default as FAQ } from './faq';
export { default as Services } from './Services';
export { default as DetailProduct } from './detailProducts';
