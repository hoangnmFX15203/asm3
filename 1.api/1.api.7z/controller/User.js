const CryptoJS = require('crypto-js');
const User = require('../models/User');
const { response } = require('express');

exports.updateUser = async (req, res) => {
    if (req.body.password) {
        req.body.password = CryptoJS.AES.encrypt(
            req.body.password,
            process.env.PASS_SEC,
        ).toString();
    }
    try {
        const updateUser = await User.findByIdAndUpdate(
            req.params.id,
            {
                $set: req.body,
            },
            { new: true },
        );
        res.status(200).json(updateUser);
    } catch (err) {
        res.status(500).json(err);
    }
};

exports.deleteUser = async (req, res) => {
    try {
        await User.findByIdAndDelete(req.params.id);
        res.status(200).json('Deleted');
    } catch (err) {
        res.status(500).json(err);
    }
};

exports.getUser = async (req, res) => {
    const { _id } = req.user;
    try {
        const user = await User.findById(_id).select(
            '-refreshToken -password -isAdmin',
        );
        const { password, ...other } = user._doc;
        res.status(200).json({
            success: true,
            res: user ? user : 'User not found',
        });
    } catch (err) {
        res.status(500).json(err);
    }
};

exports.getAllUser = async (req, res) => {
    const query = req.query.new;
    try {
        const users = query
            ? await User.find().sort({ _id: -1 }).limit(1)
            : await User.find();
        res.status(200).json(users);
    } catch (err) {
        res.status(500).json(err);
    }
};

exports.getUsers = async (req, res) => {
    const response = await User.find().select(
        '-refreshToken -password -isAdmin',
    );
    return res.status(200).json({
        success: response ? true : false,
        users: response,
    });
};

exports.deleteUser = async (req, res) => {
    const { _id } = req.query;
    if (!_id) throw new Error('Missing inputs');
    const response = await User.findByIdAndDelete(_id);
    return res.status(200).json({
        success: response ? true : false,
        deletedUser: response
            ? `User with username ${response.username} deleted`
            : 'No user delete',
    });
};

exports.updateUser = async (req, res) => {
    const { _id } = req.user;
    if (!_id || Object.keys(req.body).length === 0)
        return res.status(401).json('Missing Input');
    const response = await User.findByIdAndUpdate(_id, req.body, {
        new: true,
    }).select('-password -isAdmin');
    return res.status(200).json({
        success: response ? true : false,
        updatedUser: response ? response : 'Something went wrong',
    });
};

exports.updateUserByAdmin = async (req, res) => {
    const { uid } = req.params;
    if (Object.keys(req.body).length === 0)
        return res.status(401).json('Missing Input');
    const response = await User.findByIdAndUpdate(uid, req.body, {
        new: true,
    }).select('-password -isAdmin -refreshToken');
    return res.status(200).json({
        success: response ? true : false,
        updatedUser: response ? response : 'Something went wrong',
    });
};

exports.updateUserAddress = async (req, res) => {
    const { _id } = req.user;
    if (!req.body.address) return res.status(401).json('Missing Input');
    const response = await User.findByIdAndUpdate(
        _id,
        { $push: { address: req.body.address } },
        {
            new: true,
        },
    ).select('-password -isAdmin -refreshToken');
    return res.status(200).json({
        success: response ? true : false,
        updatedUser: response ? response : 'Something went wrong',
    });
};

exports.updateCart = async (req, res) => {
    const { pid, quantity, color } = req.body;
    const { _id } = req.user;
    if (!pid || !quantity || !color)
        return res.status(401).json('Missing Input');
    const user = await User.findById(_id).select('cart');
    let response;
    const alreadyProduct = user?.cart?.find(
        (el) => el.product.toString() === pid,
    );
    if (alreadyProduct) {
        if (alreadyProduct.color === color) {
            response = await User.updateOne(
                {
                    cart: { $elemMatch: alreadyProduct },
                },
                { $set: { 'cart.$.quantity': quantity } },
                { new: true },
            );
        } else {
            response = await User.findByIdAndUpdate(
                _id,
                {
                    $push: { cart: { product: pid, quantity, color } },
                },
                { new: true },
            );
        }
    } else {
        response = await User.findByIdAndUpdate(
            _id,
            {
                $push: { cart: { product: pid, quantity, color } },
            },
            { new: true },
        );
    }
    return res.status(200).json({
        success: response ? true : false,
        updatedCart: response ? response : 'Something went wrong',
    });
};
