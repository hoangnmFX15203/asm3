import React from 'react';
import { useParams } from 'react-router-dom';

const Products = () => {
    const { pid, title } = useParams();
    return <div>Products</div>;
};

export default Products;
