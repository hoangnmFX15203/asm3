import axios from '../axios';

export const apiRegister = (data) =>
    axios({
        url: 'auth/register',
        method: 'post',
        data: data,
    });

export const apiLogin = (data) =>
    axios({
        url: 'auth/login',
        method: 'post',
        data: data,
    });
