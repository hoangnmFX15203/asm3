import React from 'react';

const FAQ = () => {
    return <div>FAQ</div>;
};

export default FAQ;
